See [my blog](https://yuelin301.github.io/posts/LyPythonToolbox).

Memo:

```bash
python setup.py sdist bdist_wheel
```

```bash
twine upload dist/*
```

```bash
pip install --upgrade LyPythonToolbox
```